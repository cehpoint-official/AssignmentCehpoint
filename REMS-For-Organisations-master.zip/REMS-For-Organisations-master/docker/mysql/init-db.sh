#!/usr/bin/env bash
echo -e "docker-entrypoint-initdb reached...."
